import java.awt.*;
import javax.swing.*;
public class PieChartWriter extends JPanel
{private int width;
   private String fjalia1="";
   private String fjalia2="";
   private String fjalia3="";
   private String fjalia4="";
   private String fjalia5="";
   private String fjalia6="";
   private int kendi1;
   private int kendi2;
   private int kendi3;
   private int kendi4;
   private int kendi5;
   private int kendi6;
   private Color ngjyra1;
   private Color ngjyra2;
   private Color ngjyra3;
   private Color ngjyra4;
   private Color ngjyra5;
   private Color ngjyra6;
  
   public PieChartWriter(int w)
   
   { width=w;
   
      JFrame obj=new JFrame();
      obj.getContentPane().add(this);
      obj.setTitle("Pie Chart");
      obj.setSize(width,width);
      obj.setVisible(true);
   }
   public void paintComponent(Graphics g)
   {
      g.setColor(ngjyra1);
      g.fillArc(150,150,375,375,0,kendi1);
      g.drawString(fjalia1,500,160);
      g.setColor(ngjyra2);
      g.fillArc(150,150,375,375,kendi1,kendi2);
      g.drawString(fjalia2,500,175);
      g.setColor(ngjyra3);
      g.fillArc(150,150,375,375,kendi1+kendi2,kendi3);
      g.drawString(fjalia3,500,190);
      g.setColor(ngjyra4);
      g.fillArc(150,150,375,375,kendi1+kendi2+kendi3,kendi4);
      g.drawString(fjalia4,500,205);
      g.setColor(ngjyra5);
      g.fillArc(150,150,375,375,kendi1+kendi2+kendi3+kendi4,kendi5);
      g.drawString(fjalia5,500,220);
      g.setColor(ngjyra6);
      g.fillArc(150,150,375,375,kendi1+kendi2+kendi3+kendi4+kendi5,kendi6);
      g.drawString(fjalia6,500,235);
   }
   public void setSlice1(String label1,int amount1,Color color1)
   {
      fjalia1=label1;
      kendi1=amount1*360/24;
      ngjyra1=color1;
      this.repaint();
   }
   public void setSlice2(String label2,int amount2,Color color2)
   {
      fjalia2=label2;
      kendi2=amount2*360/24;
      ngjyra2=color2;
      this.repaint();
   }
   public void setSlice3(String label3,int amount3,Color color3)
   {
      fjalia3=label3;
      kendi3=amount3*360/24;
      ngjyra3=color3;
      this.repaint();
      }
   public void setSlice4(String label4,int amount4,Color color4)
   {
      fjalia4=label4;
      kendi4=amount4*360/24;
      ngjyra4=color4;
      this.repaint();}
   public void setSlice5(String label5,int amount5,Color color5)
   {
      fjalia5=label5;
      kendi5=amount5*360/24;
      ngjyra5=color5;
      this.repaint();}
   public void setSlice6(String label6,int amount6,Color color6)
   {
      fjalia6=label6;
      kendi6=amount6*360/24;
      ngjyra6=color6;
      this.repaint();}
}
